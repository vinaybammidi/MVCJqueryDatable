﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCDataTables.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult DisplayData()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult loaddata()
        {
            using (MyDatabaseEntities db = new MyDatabaseEntities())
            {
                var data = db.UserDetails.OrderBy(a => a.UserName).ToList();
                return Json(new { data = data }, JsonRequestBehavior.AllowGet);
            }

            
        }
    }
}